import { Injectable } from '@angular/core';

@Injectable()
export class ProjectmenuService {

  projectMenuList = [
  {
    id:123,
   name:'Approval'
  },
  {
    id:124,
   name:'CCAR'
  },
  {
    id:125,
   name:'CDM'
  }
];

// getProjectMenuList(){
//   return this.projectMenuList;
// }

}

