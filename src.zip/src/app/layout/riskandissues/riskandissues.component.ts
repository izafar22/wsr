import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-riskandissues',
  templateUrl: './riskandissues.component.html',
  styleUrls: ['./riskandissues.component.css']
})
export class RiskandissuesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
