import { ProjectmenuService } from './../navigation/services/projectmenu.service';
//import { Milestone } from './services/milestone.model';
//import { MilestoneDataService } from './services/milestone-data.service';
import {Component,ElementRef} from '@angular/core';
import { NgForm } from '@angular/forms';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';


@Component({
  selector: 'ngbd-modal-wsr',
  templateUrl: './wsr.modal.html'
})
export class NgbdModalWsr {
  closeResult: string;
  mycontent:any;

  constructor(private modalService: NgbModal) {}

  open(content) {
    this.mycontent=content;
    this.modalService.open(content).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

  onSubmit(form :NgForm){
    

    // this.milestoneDataService.addMilestone(milestone);
    // console.log("submitted :"+milestone);
 

  }
}