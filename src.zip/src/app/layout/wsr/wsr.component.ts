import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wsr',
  templateUrl: './wsr.component.html',
  styleUrls: ['./wsr.component.css']
})
export class WsrComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
